#include<stdio.h>
#include<locale.h>

int main()
{
        setlocale(LC_CTYPE, ""); //acentua��o

        int rgm = 123456;
        float media = 4.567788;
        printf("Dados do Aluno:\n");
        printf("RGM: %d\n", rgm);
        printf("M�dia: %.2f", media);
        return 0;
}

#include<stdio.h>
#include<locale.h>

int main ()
{
        setlocale(LC_CTYPE, ""); //acentua��o

        int quantidade;
        float preco_unitario, valor_final;
        printf("Qual a quantidade de caf�s? ");
        scanf("%d", &quantidade);
        printf("Qual o pre�o unit�rio? R$");
        scanf("%f", &preco_unitario);
        valor_final = quantidade * preco_unitario;
        printf("Total a pagar: R$ %.2f", valor_final);
        return 0;
}

#include<stdio.h>
#include<locale.h>
#define PI 3.14159
int main ()
{
        setlocale(LC_CTYPE, ""); //acentua��o

        float perimetro, raio;
        printf("Qual a medida do raio (em cm) ");
        scanf("%f", &raio);
        perimetro = 2 * PI * raio;
        printf("O per�metro da circunfer�ncia �: %.2f", perimetro);
        return 0;
}
